module Gitsh
  VERSION = '0.10'
end
