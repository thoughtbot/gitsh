module Gitsh
  VERSION = '0.6'
end
