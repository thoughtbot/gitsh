module Gitsh
  EX_OK = 0
  EX_USAGE = 64
  EX_NOINPUT = 66
  EX_UNAVAILABLE = 69
end
