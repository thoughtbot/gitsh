module Gitsh::Commands
  class Noop
    def execute(_env)
    end
  end
end
