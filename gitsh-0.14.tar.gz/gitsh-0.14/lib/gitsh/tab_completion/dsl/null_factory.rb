module Gitsh
  module TabCompletion
    module DSL
      class NullFactory
        def build(*_)
        end
      end
    end
  end
end
