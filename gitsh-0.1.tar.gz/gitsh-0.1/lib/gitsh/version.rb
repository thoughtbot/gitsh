module Gitsh
  VERSION = '0.1'
end
