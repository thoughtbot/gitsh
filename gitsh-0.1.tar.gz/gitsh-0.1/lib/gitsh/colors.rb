module Gitsh
  module Colors
    CLEAR = "\033[00m"
    RED_FG = "\033[00;31m"
    ORANGE_FG = "\033[00;33m"
    RED_BG = "\033[00;41m"
  end
end
