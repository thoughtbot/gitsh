module Gitsh
  PROGRAM_NAME = 'gitsh'
end
