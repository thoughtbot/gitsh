module Gitsh
  VERSION = '0.8'
end
