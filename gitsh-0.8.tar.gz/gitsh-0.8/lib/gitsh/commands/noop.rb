module Gitsh::Commands
  class Noop
    def execute
    end
  end
end
