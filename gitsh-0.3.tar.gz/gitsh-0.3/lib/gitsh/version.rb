module Gitsh
  VERSION = '0.3'
end
