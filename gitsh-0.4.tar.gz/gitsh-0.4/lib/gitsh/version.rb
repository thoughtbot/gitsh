module Gitsh
  VERSION = '0.4'
end
