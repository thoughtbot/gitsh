module Gitsh
  VERSION = '0.5'
end
