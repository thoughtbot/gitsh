module Gitsh
  class Comment
    def execute
    end
  end
end
