module Gitsh
  VERSION = '0.2'
end
