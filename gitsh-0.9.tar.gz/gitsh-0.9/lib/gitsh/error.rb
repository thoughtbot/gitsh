module Gitsh
  class Error < StandardError
  end

  class UnsetVariableError < Error
  end
end
